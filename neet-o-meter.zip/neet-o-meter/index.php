<?php
include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid banner p-0 position-relative">
        <img src="images/content-styled-image-new.png" class="banner-bk">
        <div class="container position-relative h-100" style="z-index: 1;">
            <div class="row align-items-center h-100">
                <div class="col-12 col-md-6 banner-content">
                    <div>
                        <h2 class="animate__zoomIn animate__animated wow">THE MOST PROGRESSIVE <span>EDUCATION</span> WORDPRESS THEME</h2>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <canvas id="chart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-0 sign-in-wrap">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 top-wrap py-6 px-0 d-md-flex justify-content-between">
                    <div class="whyus-in d-flex align-items-start animate__fadeInUp animate__animated wow">
                        <img src="images/schollar.png">
                        <div class="ml-3">
                            <h5>Scholarship Facility</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                    <div class="whyus-in d-flex align-items-start my-4 my-md-0 mx-md-4 animate__fadeInUp animate__animated wow">
                        <img src="images/skilled.png">
                        <div class="ml-3">
                            <h5>Skilled Lecturers</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                    <div class="whyus-in d-flex align-items-start animate__fadeInUp animate__animated wow">
                        <img src="images/library.png">
                        <div class="ml-3">
                            <h5>Book Library & Store</h5>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 about-wrap position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 abt-main-wrap d-md-flex justify-content-between">
                    <div class="col-12 col-md-6">
                        <div class="col-12 main-heaing">
                            <h2 class="animate__fadeInUp animate__animated wow text-white">Preparing for <span>NEET?</span> Come learn at NEET-O-METER</h2>
                        </div>
                        <div class="col-12  about-counter-cell">

                            <div class=" d-flex align-items-center ">
                                <div>
                                    <canvas id="chart"></canvas>
                                </div>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>CONCEPTS</h6>
                                </div>
                            </div>
                            <div class=" d-flex align-items-center ">
                                <canvas id="chart"></canvas>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>VIDEO e-LECTURES</h6>
                                </div>
                            </div>
                            <div class=" d-flex align-items-center ">
                                <canvas id="chart"></canvas>
                                <div>
                                    <h4><span class="counter wow" data-target="12000"></span>+</h4>
                                    <h6>FACULTY SUPPORT</h6>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-12 col-md-6 abt-info">

                        <div class="content text-white">
                            <p class="animate__fadeInUp animate__animated wow">Prepare for NEET 2022 or 2023 with the most thorough and exhaustive online homeroom program by the world's biggest Ed-Tech organization.</p>

                            <p class="animate__fadeInUp animate__animated wow">Ordinary online classes by India's driving NEET coaches</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER offer you Online Classes that will be directed 3-5 times each week by India's Best NEET Trainers. This will assist you with understanding the idea altogether and guarantee that every one of your questions is cleared.</p>

                            <p class="animate__fadeInUp animate__animated wow">In-depth conversation of Daily Practice Problems (DPPs) and Practice Sheets</p>

                            <p class="animate__fadeInUp animate__animated wow">The very much planned and organized DPP will help you amend the ideas consistently for every one of the subjects. Practice Sheet conversation guarantees that you figure out how to apply the ideas educated in the class.</p>

                            <p class="animate__fadeInUp animate__animated wow">All India Tests to benchmark yourself against different students</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER All India Test Series (AITS) for NEET led once at regular intervals will measure your exhibition PAN India and improve your test-taking abilities. Each test is trailed by definite input to assist you with understanding the holes in your planning.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid  py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow text-center">Start your <span>NEET</span> preparation now</h2>
                    <p class="animate__fadeInUp animate__animated wow text-center">You don't have to struggle alone, you've got our assistance and help.</p>
                </div>
                <div class="col-12 tabcontent active">
                    <div class="team-box row mb-5">
                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#DD246E;">
                            <div class="prep-img-box">
                                <img src="images/study-material.png">
                            </div>
                            <h4>Smart Study Material</h4>
                            <ul>
                                <li>20000+ Chapter wise <b>NEET questions</b></li>
                                <li>5000+ NEET concept wise <b>videos</b></li>
                                <li>1200+ Most asked <b>NEET concepts</b></li>
                                <li>1000+ Most difficult <b>NEET concepts</b></li>
                                <li>10 years solved <b>NEET question papers</b></li>
                                <li>5000+ Concept wise <b>Flash Cards</b></li>
                                <li>Weekend <b>Live Classes</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#8007E6 ;">
                            <div class="prep-img-box">
                                <img src="images/mocktest.png">
                            </div>
                            <h4>NEET Mock Test Series</h4>
                            <ul>
                                <li>Unlimited - <b>chapter wise tests</b></li>
                                <li>Unlimited - <b>subject wise tests</b></li>
                                <li>Unlimited - <b>Full mock tests</b></li>
                            </ul>
                        </div>


                        <div class="prep-cell animate__fadeInUp animate__animated wow" style="background:#0CAE74;">
                            <div class="prep-img-box">
                                <img src="images/performance.png">
                            </div>
                            <h4>Performance Analysis</h4>
                            <ul>
                                <li><b>Prepmeter</b> - Check how ready you are for NEET</li>
                                <li><b>Strength Sheet</b> - Know your top performing areas</li>
                                <li><b>Weakness Sheet</b> - Know your areas to improve</li>
                                <li><b>Skills Graph</b> - Know how your skill-set is improving</li>
                                <li><b>Rank Predictor</b> - Estimate your rank in advance</li>
                            </ul>
                        </div>
                    </div>
                    <h4 class="prep-btm-text animate__fadeInUp animate__animated wow">Live NEET doubt solving with <span>24x7</span> faculty support</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative service-main-wrap" id="feature">
        <img src="assets/ser-bk.png" class="service-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">

                    <h2 class="text-white text-center animate__fadeInUp animate__animated wow"><span>Feature</span> of NEET-O-METER.
                    </h2>
                    <p class="text-white text-center animate__fadeInUp animate__animated wow">Advance systems make us uniq, help you to grow your career</p>
                </div>
                <div class="col-12 mb-5 pb-5">
                    <div class="team-box row p-0 m-0">
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/ai.png">
                                <h4>AI DRIVEN PERSONALISED MENTOR</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/mocktest.png">
                                <h4>UNLIMITED MOCK TEST+ PREVIOUS PAPERS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/timetable.png">
                                <h4>CUSTOMISED TIMETABLE</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/performance.png">
                                <h4>PERFORNMENCE ANALYSIS</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/exam.png">
                                <h4>EXAM STRATEGY PLANNING</h4>
                            </div>
                        </div>
                        <div class=" ser-cell col-12 col-md-3 p-0 animate__fadeInUp animate__animated wow">
                            <div class="service-list-box ser-box ">
                                <img src="images/study-material.png">
                                <h4>SMART STUDY MATERIAL</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid vdo-wrap p-0 vdo-sec h-auto position-relative">
        <img src="images/kenny-eliason-1-aA2Fadydc-unsplash.jpg">
        <button><img src="images/play.png"></button>
    </div>
    <div class="container-fluid py-6 meter-sec">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 meter wrap">
                    <div>
                        <canvas id="chart"></canvas>
                    </div>
                    <div>
                        <canvas id="chart"></canvas>
                    </div>
                    <div>
                        <canvas id="chart"></canvas>
                    </div>
                    <div>
                        <canvas id="chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative overflow-hidden" id="plans">
        <img src="images/get_masterstudy_background.png" class="price-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center animate__fadeInUp animate__animated wow">Learn Prep Plans now</h2>
                </div>
                <div class="col-12 tabcontent">
                    <div class="team-box row m-0 p-0">

                        <div class="prep-cell p-0 animate__fadeInUp animate__animated wow">
                            <div class="price-box blue">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 14999<br><span>per month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                        <div class=" prep-cell p-0 animate__fadeInUp animate__animated wow">
                            <div class="price-box pink">
                                <h2 class="price"><i class="fas fa-rupee-sign"></i> 24999<br><span>per month</span></h2>

                                <div class="price-cell">
                                    <h3 class="course-name">CRASH COURSE2</h3>
                                    <ul class="course-detail">
                                        <li>1x option 1</li>
                                        <li>2x option 2</li>
                                        <li>3x option 3</li>
                                        <li>Free option 4</li>
                                        <li>Unlimited option 5</li>
                                    </ul>
                                    <a>Buy Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid app-sec py-6 position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-5">
                    <div class="col-12 main-heaing">
                        <h2 class="animate__fadeInUp animate__animated wow text-white">NEET-O-METER App For IOS & Android</h2>
                    </div>
                    <div class="content-2 text-white animate__fadeInUp animate__animated wow ">
                        <p>NEET-O-METER App is a mobile learning application to start eLearning fast and let the
                            students take courses on the go. The app was based on the idea of the frequent presence of
                            modern users on the mobile platform.</p>
                    </div>
                    <div class="download-box">
                        <a class="animate__fadeInUp animate__animated wow "><img src="images/apple.png"></a>
                        <a class="animate__fadeInUp animate__animated wow "><img src="images/android.png"></a>
                    </div>
                </div>
                <div class="col-12 col-md-7">
                    <img src="images/iphone-mockup-med.png" class="app-mb">
                    <img src="images/header_element_dots_o_1.png" class="app-bk">
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative nps-sec" style="overflow:hidden;">
        <img src="images/destination-3d-render-icon-illustration-png.png" class="nps-bk">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow text-white text-center">NEET Positioning System</h2>
                    <p class="text-white text-center animate__fadeInUp animate__animated wow">Track your progress</p>
                </div>
                <div class="content text-white">
                    <p class="animate__fadeInUp animate__animated wow text-center">Prepare for NEET 2022 or 2023 with the most thorough and exhaustive online homeroom program by the world's biggest Ed-Tech organization.</p>
                </div>
                <div class="nps-wrap col-12 mt-5">
                    <div class="nps-box">
                        <img src="images/1993012.png" class="nps-pointer">
                        <p class="nps-start">Start</p>
                        <img src="images/1608287595_mNhquO_demand_supply_synergy3_01_01.png" class="nps-img">
                        <p class="nps-des">Destination</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 col-md-4 main-heaing">
                    <h2 class="animate__fadeInUp animate__animated wow">Sample test for visitors</h2>
                </div>
                <div class="col-12 col-md-8 sub-header">
                    <div class="d-flex align-items-center justify-content-end w-100">
                        <a href="javascript:void(0);" class="tablinks active-a">Physics</a>
                        <a href="javascript:void(0);" class="tablinks">Chemistry</a>
                        <a href="javascript:void(0);" class="tablinks">Biology</a>
                    </div>
                </div>
                <div class="col-12">
                    <div class="tab-content active">
                        <div class="owl-carousel owl-theme phy-q-owl">
                            <div class="item">
                                <div class="papper-box">
                                    <h6>The Living World</h6>
                                    <h5>Physics</h5>
                                    <div class="btn-con">
                                        <a href="#" class="light btn-primary m-0"><i class="fas fa-clipboard Test mr-3"></i>Take Test</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <? include_once("includes/whyus.php"); ?>
    <? include_once("includes/testimonial.php"); ?>
    <? include_once("includes/footer.php"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
</body>
<script>
    new WOW().init();
    $('.phy-q-owl').owlCarousel({
        loop: false,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 1
            },
            1500: {
                items: 5
            }
        }
    })
</script>
<script>
    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };

    var randomData = function() {
        return [
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor(),
            randomScalingFactor()
        ];
    };

    var randomValue = function(data) {
        return Math.max.apply(null, data) * Math.random();
    };

    var data = randomData();
    var value = randomValue(data);

    var config = {
        type: 'gauge',
        data: {
            labels: ['Success', 'Warning', 'Warning', 'Error'],
            datasets: [{
                data: data,
                value: value,
                backgroundColor: ['#0b152c', '#3e3f3e', '#dc1e33', '#c32032'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,

            },
            layout: {
                padding: {
                    bottom: 30
                }
            },
            needle: {
                // Needle circle radius as the percentage of the chart area width
                radiusPercentage: 2,
                // Needle width as the percentage of the chart area width
                widthPercentage: 3.2,
                // Needle length as the percentage of the interval between inner radius (0%) and outer radius (100%) of the arc
                lengthPercentage: 80,
                // The color of the needle
                color: 'rgba(14, 30, 42, 1)'
            },
            valueLabel: {
                formatter: Math.round
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById('chart').getContext('2d');
        window.myGauge = new Chart(ctx, config);
    };

    document.getElementById('randomizeData').addEventListener('click', function() {
        config.data.datasets.forEach(function(dataset) {
            dataset.data = randomData();
            dataset.value = randomValue(dataset.data);
        });

        window.myGauge.update();
    });

</script>
<script>
    const counters = document.querySelectorAll(".counter");

    counters.forEach((counter) => {
        counter.innerText = "0";
        const updateCounter = () => {
            const target = +counter.getAttribute("data-target");
            const count = +counter.innerText;
            const increment = target / 200;
            if (count < target) {
                counter.innerText = `${Math.ceil(count + increment)}`;
                setTimeout(updateCounter, 1);
            } else counter.innerText = target;
        };
        updateCounter();
    });
</script>

</html>