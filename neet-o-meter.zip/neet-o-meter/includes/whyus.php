<div class="container-fluid blue-sec py-6 position-relative ash-bk">
        <img src="https://madkk.com/pasdigi/WP/PASDT/wp-content/uploads/2022/11/copernico-p_kICQCOM4s-unsplash-1-1.jpg " class="animate__zoomIn animate__animated wow why-img-lft animated" style="visibility: visible; animation-name: zoomIn;">
        <div class="container my-md-5">
            <div class="row">
                <div class="col-12 why-grid">

                    <div class="col-12 main-heaing">
                        <h2 class="animate__fadeInUp animate__animated wow ">Reasons Why We Are <span>Best</span>
                        </h2>
                    </div>
                    <div class="col-12 welcome-one__solutions mb-0">
                        <div class="content ">
                            <ol class="why-count">
                                <li class="animate__fadeInUp animate__animated wow ">Technology Leaders We are a team of new-age tech lovers who research &amp; innovate for revolutionary digital solutions that guarantee unmatched performance &amp; growth.</li>
                                <li class="animate__fadeInUp animate__animated wow ">Relationship-Based Model We build relationships to provide our clients with substantial value through adaptable engagement and pricing structures.</li>
                                <li class="animate__fadeInUp animate__animated wow ">One-Stop-Solution Our complete range of digital solutions reduces costs and provides entire project ownership with excellent quality and prompt delivery.</li>
                                <li class="animate__fadeInUp animate__animated wow ">Happy Clientele For years, we have delivered custom, data-based, scalable digital innovations for global businesses with cutting-edge solutions.</li>
                                <li class="animate__fadeInUp animate__animated wow ">Reliable Our group is active 24/7. You can always rely on us to respond to emergencies, whether they arise on a Sunday, a holiday, or Christmas Eve.</li>
                                <li class="animate__fadeInUp animate__animated wow ">Dedicated Team Receive the same degree of individualized attention regardless of the project's worth with additional support personnel specifically focused on your project.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>